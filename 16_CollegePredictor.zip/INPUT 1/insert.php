<!DOCTYPE html>
<html>

<head>
	<title>Insert Page page</title>
</head>

<body>
	<center>
		<?php

		$conn = mysqli_connect("127.0.0.1:3325", "root", "", "college_chooser");
		
		if($conn === false){
			die("ERROR: Could not connect. "
				. mysqli_connect_error());
		}
		
		$name = $_REQUEST['name'];
		$rank = $_REQUEST['rank'];
		
		$sql = "INSERT INTO student (name,exam_rank) VALUES ('$name',
			'$rank')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>Data stored successfully.";
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		mysqli_close($conn);
		?>
		<br>
		<a href="http://localhost/DBMS%20PROJECT/index.php">Go to Home</a>
	</center>
</body>

</html>
