<!DOCTYPE html>
<html lang="en">

<head>
    <title>GFG- Store Data</title>
</head>

<body>
    <center>
        <h1>Enter your details</h1>

        <form action="insert.php" method="post">

            <p>
                <label for="Name">Name:</label>
                <input type="text" name="name" id="Name">
            </p>

            <p>
                <label for="Rank">Rank:</label>
                <input type="text" name="rank" id="Rank">
            </p>

            <input type="submit" value="Submit">
        </form>
    </center>
</body>

</html>