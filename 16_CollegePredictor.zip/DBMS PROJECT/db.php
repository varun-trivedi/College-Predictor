<?php
    $server = '127.0.0.1:3325';
    $user = 'root';
    $pass = '';
    $dbname = 'college_chooser';
    $conn = mysqli_connect($server, $user, $pass, $dbname);


    if(!$conn){
        die("CONNECTION FAILED." . mysqli_connect_error());
    }
?>