-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3325
-- Generation Time: Dec 02, 2021 at 07:42 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `college_chooser`
--

-- --------------------------------------------------------

--
-- Table structure for table `application`
--

CREATE TABLE `application` (
  `aid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `sid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `application`
--

INSERT INTO `application` (`aid`, `uid`, `sid`) VALUES
(1, 5, 2),
(2, 20, 5);

-- --------------------------------------------------------

--
-- Table structure for table `institute`
--

CREATE TABLE `institute` (
  `uid` int(11) NOT NULL,
  `I_name` varchar(32) DEFAULT NULL,
  `Degree` varchar(20) DEFAULT NULL,
  `Pool` varchar(32) DEFAULT NULL,
  `Program` varchar(80) DEFAULT NULL,
  `Cutoff` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `institute`
--

INSERT INTO `institute` (`uid`, `I_name`, `Degree`, `Pool`, `Program`, `Cutoff`) VALUES
(1, 'IIT Bombay', 'B.Tech', 'Gender-Neutral', 'Computer Science and Engineering', 60),
(2, 'IIT Bombay', 'B.Tech', 'Female-Only', 'Computer Science and Engineering', 100),
(3, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Computer Science and Engineering', 120),
(4, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Computer Science and Engineering', 150),
(5, 'IIT Bombay', 'B.Tech', 'Gender-Neutral', 'Electronics and Communication Engineering', 200),
(6, 'IIT Bombay', 'B.Tech', 'Female-Only', 'Electronics and Communication Engineering', 230),
(7, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Electronics and Communication Engineering', 270),
(8, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Electronics and Communication Engineering', 300),
(9, 'IIT Bombay', 'B.Tech', 'Gender-Neutral', 'Mechanical Engineering', 330),
(10, 'IIT Bombay', 'B.Tech', 'Female-Only', 'Mechanical Engineering', 350),
(11, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Mechanical Engineering', 380),
(12, 'IIT Bombay', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Mechanical Engineering', 400),
(13, 'IIT Delhi', 'B.Tech', 'Gender-Neutral', 'Computer Science and Engineering', 350),
(14, 'IIT Delhi', 'B.Tech', 'Female-Only', 'Computer Science and Engineering', 400),
(15, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Computer Science and Engineering', 450),
(16, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Computer Science and Engineering', 500),
(17, 'IIT Delhi', 'B.Tech', 'Gender-Neutral', 'Electronics and Communication Engineering\r\n', 550),
(18, 'IIT Delhi', 'B.Tech', 'Female-Only', 'Electronics and Communication Engineering\r\n', 600),
(19, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Electronics and Communication Engineering\r\n', 650),
(20, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Electronics and Communication Engineering\r\n', 700),
(21, 'IIT Delhi', 'B.Tech', 'Gender-Neutral', 'Mechanical Engineering', 750),
(22, 'IIT Delhi', 'B.Tech', 'Female-Only', 'Mechanical Engineering', 800),
(23, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Mechanical Engineering', 850),
(24, 'IIT Delhi', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Mechanical Engineering', 900),
(25, 'IIT Roorkee', 'B.Tech', 'Gender-Neutral', 'Computer Science and Engineering', 800),
(26, 'IIT Roorkee', 'B.Tech', 'Female-Only', 'Computer Science and Engineering', 850),
(27, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Computer Science and Engineering', 900),
(28, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Computer Science and Engineering', 950),
(29, 'IIT Roorkee', 'B.Tech', 'Gender-Neutral', 'Electronics and Communication Engineering', 1000),
(30, 'IIT Roorkee', 'B.Tech', 'Female-Only', 'Electronics and Communication Engineering', 1050),
(31, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Electronics and Communication Engineering', 1100),
(32, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Electronics and Communication Engineering', 1200),
(33, 'IIT Roorkee', 'B.Tech', 'Gender-Neutral', 'Mechanical Engineering', 1250),
(34, 'IIT Roorkee', 'B.Tech', 'Female-Only', 'Mechanical Engineering', 1300),
(35, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Gender-Neutral', 'Mechanical Engineering', 1350),
(36, 'IIT Roorkee', 'B.Tech-M.Tech(DD)', 'Female-Only', 'Mechanical Engineering', 1400);

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `exam_rank` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `name`, `exam_rank`) VALUES
(1, 'Yash', 217),
(2, 'Varun', 120),
(3, 'Tathya', 35),
(4, 'Aayush', 269),
(5, 'Saksham', 137),
(6, 'Aayush Jain', 40924),
(7, 'Tathya Sethi', 118),
(8, 'Tathya Sethi', 118),
(9, 'Utkarsh', 344),
(10, 'suryansh', 4300);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `application`
--
ALTER TABLE `application`
  ADD PRIMARY KEY (`aid`),
  ADD KEY `uid` (`uid`),
  ADD KEY `sid` (`sid`);

--
-- Indexes for table `institute`
--
ALTER TABLE `institute`
  ADD PRIMARY KEY (`uid`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `application`
--
ALTER TABLE `application`
  MODIFY `aid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `student`
--
ALTER TABLE `student`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `application`
--
ALTER TABLE `application`
  ADD CONSTRAINT `application_ibfk_1` FOREIGN KEY (`uid`) REFERENCES `institute` (`uid`),
  ADD CONSTRAINT `application_ibfk_2` FOREIGN KEY (`sid`) REFERENCES `student` (`sid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
