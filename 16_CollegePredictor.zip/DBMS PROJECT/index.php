<!doctype html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300&display=swap" rel="stylesheet">
    <title>Document</title>
</head>

<style>
    * {
        margin: 0;
        padding: 0;
        font-family: 'Roboto', sans-serif;
    }

    body {
        background: url(images/LNM.png);
        background-size: cover;
        background-repeat: no-repeat;
        background-attachment: fixed;
    }

    header div {
        opacity: 80%;
        width: 100vw;
        text-align: center;
        background-color: black;
    }

    p {
        padding: 20px;
        font-size: 40px;
        color: white;
        font-weight: bold;
    }

    section div {
        opacity: 80%;
        margin: 20px;
        border: 1px solid white;
        padding: 10px;
        background-color: black;
    }

    ul {
        list-style: none;
    }

    li {
        color: white;
        margin-left: 80px;
        margin-bottom: 10px;
        margin-top: 10px;
        display: inline-block;
    }

    h2 {
        margin-bottom: 10px;
        margin-left: 10px;
        color: white;
    }

    th,
    td {
        color: white;
        padding: 0px 20px;
    }

    .sub-btn {
        padding: 2px;
    }

    a{
        border: 1px solid black;
        color: white;
        padding: 10px 5px 10px 8px;
        max-width: 150px;
        background-color: grey;
        text-decoration: none;
        position: absolute;
        top: 14px;
        right: 14px;
    }
</style>

<body>
    <header>
        <div>
            <p>COLLEGE PREDICTOR</p>
        </div>
        <a href="http://localhost/INPUT%201/">If you are a student, click here to register</a>
    </header>
    <section>
        <div>
            <h2>
                Enter the following details to know the cutoff :
            </h2>
            <form action="index.php" method="post">
                <ul>
                    <li>
                        <label for="Institute">Institute</label>
                        <select name="institute" id="Institute" required>
                            <option>Select</option>
                            <option value="IIT Bombay">IIT Bombay</option>
                            <option value="IIT Delhi">IIT Delhi</option>
                            <option value="IIT Roorkee">IIT Roorkee</option>
                        </select>
                    </li>
                    <li>
                        <label for="Degree">Degree</label>
                        <select name="degree" id="Degree" required>
                            <option>Select</option>
                            <option value="B.Tech">B.Tech</option>
                            <option value="B.Tech-M.Tech(DD)">B.Tech-M.Tech(DD)</option>
                        </select>
                    </li>
                    <li>
                        <label for="Pool">Pool</label>
                        <select name="pool" id="Pool" required>
                            <option>Select</option>
                            <option value="Gender-Neutral">Gender-Neutral</option>
                            <option value="Female-Only">Female-Only</option>
      +                  </select>
                    </li>
                    <li>
                        <label for="Program">Program</label>
                        <select name="program" id="Program" required>
                            <option>Select</option>
                            <option value="Computer Science and Engineering">Computer Science and Engineering</option>
                            <option value="Electronics and Communication Engineering">Electronics and Communication Engineering</option>
                            <option value="Mechanical Engineering">Mechanical Engineering</option>
                        </select>
                    </li>
                    <li>
                        <input type="submit" name="submit" class="sub-btn">
                    </li>
                </ul>
            </form>
        </div>
        <div>
            <h2>Rank based filter :</h2>
            <form action="index.php" method="post">
                <ul>
                    <li>
                        <label for="Rank">Rank</label>
                        <input type="number" id="Rank" name="rank">
                    </li>
                    <li>
                        <input type="submit" name="sub" class="sub-btn">
                    </li>
                </ul>
            </form>
        </div>

        <div>
            <table>
                <thead>
                    <tr>
                        <th>Institute</th>
                        <th>Degree</th>
                        <th>Pool</th>
                        <th>Program</th>
                        <th>Cutoff</th>
                    </tr>
                </thead>

                <tbody>
                    <?php
                    $institute = '';
                    $degree = '';
                    $pool = '';
                    $program = '';
                    // $rank = '';
                    include("db.php");
                    if (isset($_POST['submit'])) {
                        $institute = $_POST['institute'];
                        $degree = $_POST['degree'];
                        $pool = $_POST['pool'];
                        $program = $_POST['program'];
                        // $rank = $_POST['rank'];
                    }
                    if ($institute != '' || $degree != '' || $pool != '' || $program != '') {
                        $query = "SELECT * FROM institute WHERE I_name = '$institute' AND Degree = '$degree' AND Pool = '$pool' AND Program = '$program'";
                        $data = mysqli_query($conn, $query);
                        if ($data !== false && $data->num_rows > 0) {
                            while ($row = $data->fetch_assoc()) {
                    ?>
                                <tr>
                                    <td><?php echo $row['I_name']; ?></td>
                                    <td><?php echo $row['Degree']; ?></td>
                                    <td><?php echo $row['Pool']; ?></td>
                                    <td><?php echo $row['Program']; ?></td>
                                    <td><?php echo $row['Cutoff']; ?></td>
                                </tr>;
                            <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <td>No Records Found</td>
                            </tr>
                            <?php
                        }
                    }
                    $rank = '';
                    if (isset($_POST['sub'])) {
                        $rank = $_POST['rank'];
                    }
                    if ($rank != '') {
                        $query = "SELECT * FROM institute WHERE Cutoff <= '$rank' ORDER BY Cutoff ASC";
                        $data = mysqli_query($conn, $query);
                        if ($data !== false && $data->num_rows > 0) {
                            while ($row = $data->fetch_assoc()) {
                            ?>
                                <tr>
                                    <td><?php echo $row['I_name']; ?></td>
                                    <td><?php echo $row['Degree']; ?></td>
                                    <td><?php echo $row['Pool']; ?></td>
                                    <td><?php echo $row['Program']; ?></td>
                                    <td><?php echo $row['Cutoff']; ?></td>
                                </tr>;
                            <?php
                            }
                        } else {
                            ?>
                            <tr>
                                <br>
                                <td>No Records Found</td>
                                <br>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </section>
</body>

</html>